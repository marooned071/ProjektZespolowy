package com.example.qrpoll;

public class Exception404 extends Exception{
	Exception404(){
		super();
	}
}