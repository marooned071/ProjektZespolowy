package com.example.qrpoll;

public class QRScanner {
	

}
